module.exports = {
  lintOnSave: false, // 关闭eslint语法校验规则
  runtimeCompiler: true // 使用包含运行时编译器的Vue内核版本
  // devServe: {
  //     proxy: 'http://toutiao-app.itheima.net/'
  // }
}
